package onetomany;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity  //import javax.persistence.Entity;
@Table(name="emp6")
public class Employee {

	//3
		@Id // this is the primary key
		@Column(name="empno")
		private int employeeNumber;
		
		@Column(name="ename", length=20)
		private String employeeName;
		
		@Column(name="job", length=20)
		private String employeeJob;
		
		@Column(name="sal")
		private float salary;
		
		
		@ManyToOne
		@JoinColumn(name="dno") //for DB - FK column 
		Department dept; //for Java

		
		
		

		public Employee() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		


		public Employee(int employeeNumber, String employeeName, String employeeJob, float salary) {
			super();
			this.employeeNumber = employeeNumber;
			this.employeeName = employeeName;
			this.employeeJob = employeeJob;
			this.salary = salary;
		}




		public Employee(int employeeNumber, String employeeName, String employeeJob, float salary, Department dept) {
			super();
			this.employeeNumber = employeeNumber;
			this.employeeName = employeeName;
			this.employeeJob = employeeJob;
			this.salary = salary;
			this.dept = dept;
		}




		public int getEmployeeNumber() {
			return employeeNumber;
		}


		public void setEmployeeNumber(int employeeNumber) {
			this.employeeNumber = employeeNumber;
		}


		public String getEmployeeName() {
			return employeeName;
		}


		public void setEmployeeName(String employeeName) {
			this.employeeName = employeeName;
		}


		public String getEmployeeJob() {
			return employeeJob;
		}


		public void setEmployeeJob(String employeeJob) {
			this.employeeJob = employeeJob;
		}


		public float getSalary() {
			return salary;
		}


		public void setSalary(float salary) {
			this.salary = salary;
		}


		public Department getDept() {
			return dept;
		}


		public void setDept(Department dept) {
			this.dept = dept;
		}
		
		
		
}

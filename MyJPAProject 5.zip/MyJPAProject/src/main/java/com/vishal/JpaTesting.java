package com.vishal;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JpaTesting {
	public static void main(String[] args) {

		
		//below line would read META-INF/persistence.xml file and will search for
		
		//the persistence unit name as MyJPA
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("entityManagerFactory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("entityManager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		Department dept  = new Department();
		dept.setDepartmentNumber(99);
		dept.setDepartmentName("QUALITY");
		dept.setDepartmentLocation("Andhei");
		
		transaction.begin();
			entityManager.persist(dept);
		transaction.commit();
	}
}
//@Transactional



/*

			db
			|
			Department
			|
			repository
			|
			Service	
				controller - @RequestBody -- Department 
						|
angular form : customer data entry
*/



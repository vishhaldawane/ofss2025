package com.vishal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/*  	 
    1. must be in a package
    2. class must be public      
    3. data as private
    4. must have no-arg ctor
    5. introspective methods | setter|getter
    
    ORM object relation mapping
*/
//POJO
@Entity  //import javax.persistence.Entity;
@Table(name="dept")
public class Department { //2 -- class is mapped with the table structure
	
	//3
	@Id // this is the primary key
	@Column(name="deptno")
	private int departmentNumber;
	
	@Column(name="dname")
	private String departmentName;
	
	@Column(name="loc")
	private String departmentLocation;
	
	@OneToOne
	Head hod;
	
	public Department() { //4
		System.out.println("Department() ctor....");
	}

	//5
	public int getDepartmentNumber() {
		return departmentNumber;
	}

	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getDepartmentLocation() {
		return departmentLocation;
	}

	public void setDepartmentLocation(String departmentLocation) {
		this.departmentLocation = departmentLocation;
	}
	
	
}

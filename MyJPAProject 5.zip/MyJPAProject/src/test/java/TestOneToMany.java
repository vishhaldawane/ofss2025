import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import onetomany.Department;
import onetomany.Employee;
import onetoone.Person;

public class TestOneToMany {

EntityManager manager;
	
	@BeforeEach
	public void setUp() 
	{
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Entity Manager Factory created");
		manager = factory.createEntityManager();
		System.out.println("Entity Manager created");		
	}
	
	@Test
	public void testAddDepartmentWithEmployees() {
		
		Department dept = new Department();
		Department dept2 = new Department();
		
		
		dept.setDepartmentNumber(10);
		dept.setDepartmentName("IT");
		dept.setDepartmentLocation("NJ");
		
		dept2.setDepartmentNumber(20);
		dept2.setDepartmentName("Sales");
		dept2.setDepartmentLocation("ND");
		
		Employee emp1 = new Employee(501,"Suresh","Dba",8000,dept);
		Employee emp2 = new Employee(502,"Dinesh","Analyst",4000,dept);
		Employee emp3 = new Employee(503,"Rajesh","Developer",3000,dept);

		Employee emp4 = new Employee(901,"Julie","Saleswomen",9000,dept2);
		Employee emp5 = new Employee(902,"Julia","Manager",9300,dept2);
		Employee emp6 = new Employee(903,"Jenny","Clerk",9200,dept2);

		
		dept.getEmployees().add(emp1); //new row for this emp1
		dept.getEmployees().add(emp2); //new row for this emp1
		dept.getEmployees().add(emp3); //new row for this emp1
		
		dept2.getEmployees().add(emp4); //new row for this emp1
		dept2.getEmployees().add(emp5); //new row for this emp1
		dept2.getEmployees().add(emp6); //new row for this emp1
		
		EntityTransaction trans = manager.getTransaction();
		trans.begin();
			manager.persist(dept);
			manager.persist(dept2);
			
		trans.commit();
	}
	
	/*
	 
		Knowledge implemented is Wisdom
		
		4th Generation Time Table
		
				U			NU
		-----------------------
		I	|  DO		| Schedule
			|			|
		-----------------------
		NI	| Delegate  | Eliminate
 
 	
 	Sunday - 24
 	
 	MAy
 	
 	June
 	
 	
 	Dec
 	------
 	3 yr
 	
 	5 yr
 	
 	10 yr
 	
 	20 yr
 	
 	30 yr
 
 				TKI model
 
 					  |	
 			    100   | Compete		 collaboration
		Assertiveness |
 					  |
 					  |			compromise
 				50	  |---------+
 					  |			|  Accomodate
 					 0| Avoid	|
 					 +----------------------------->
 					  0			50				100
 					 		Co Operativeness
	*/
	
	@Test
	public void testRetrieveEmployeesFromADepartmentTest() {
		Department dept = manager.find(Department.class, 20);
	Assertions.assertTrue(dept!=null);
		
		System.out.println("Dept No   : "+dept.getDepartmentNumber());
		System.out.println("Dept Name : "+dept.getDepartmentName());
		System.out.println("Dept Loc  : "+dept.getDepartmentLocation());
		
		List<Employee> staff =  dept.getEmployees();
		
	Assertions.assertTrue(staff.size() > 0 );
		for(Employee emp : staff) {
			System.out.println("Emp No   : "+emp.getEmployeeNumber());
			System.out.println("Emp Name : "+emp.getEmployeeName());
			System.out.println("Emp Job  : "+emp.getEmployeeJob());
			System.out.println("Emp Sal   : "+emp.getSalary());
	
		}
	/*
		staff.forEach( (emp)-> {
			System.out.println("Emp No   : "+emp.getEmployeeNumber());
			System.out.println("Emp Name : "+emp.getEmployeeName());
			System.out.println("Emp Job  : "+emp.getEmployeeJob());
			System.out.println("Emp Sal  : "+emp.getSalary());
		});
		*/
	//	Iterator<Employee> iter = staff.iterator();
	
		//printThem(iter);
		
	}
	
	public static void printThem(Iterator<Employee> iter) {
		while(iter.hasNext()) {
			Employee theEmp = iter.next();
			System.out.println("Emp No   : "+theEmp.getEmployeeNumber());
			System.out.println("Emp Name : "+theEmp.getEmployeeName());
			System.out.println("Emp Job  : "+theEmp.getEmployeeJob());
			System.out.println("Emp Sal   : "+theEmp.getSalary());
	
		}
	}
}

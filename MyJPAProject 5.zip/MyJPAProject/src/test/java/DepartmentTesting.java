import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;

import com.vishal.Department;

public class DepartmentTesting {

	
	@Test
	public void insertDepartmentTest() {

		
		//below line would read META-INF/persistence.xml file and will search for
		
		//the persistence unit name as MyJPA
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("entityManagerFactory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("entityManager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		Department dept  = new Department();
		dept.setDepartmentNumber(89);
		dept.setDepartmentName("QMS");
		dept.setDepartmentLocation("Pune");
		
		transaction.begin();
			entityManager.persist(dept);
		transaction.commit();
	}
}

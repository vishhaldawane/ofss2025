

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import manytomany.Customer;
import manytomany.Subscription;

public class CustomerSubscriptionTest {

	EntityManager manager;
	
	@BeforeEach
	public void setUp() 
	{
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Entity Manager Factory created");
		manager = factory.createEntityManager();
		System.out.println("Entity Manager created");		
	}
	
	@Test
	public void testCase1() {
		EntityTransaction trans = manager.getTransaction();
		trans.begin();
		Customer cust = new Customer();
		cust.setName("Jack"); cust.setEmail("jack@gmail.com");
		System.out.println("customer 1 is created...");
		
		manager.persist(cust);
		System.out.println("customer 1 is merged...");
		
		cust = new Customer();
		cust.setName("Janet"); cust.setEmail("janet@gates.com");
		System.out.println("customer 2 is created...");
		
		manager.persist(cust);
		System.out.println("customer 2 is merged...");
		
		Subscription subs = new Subscription();
		subs.setType("Book"); subs.setDuration(30);
		System.out.println("Subscription 1 is created...");
		
		manager.persist(subs);
		System.out.println("Subscription 1 is merged...");
		
		
		subs = new Subscription();
		subs.setType("CD And DVD"); subs.setDuration(7);
		System.out.println("Subscription 2 is created...");
		
		manager.persist(subs);
		System.out.println("Subscription 2 is merged...");
		
		trans.commit();
	}
	
	@Test
	public void testCase2() {
	//ADD 2 CUSTOMERS(41,42) AND 2 SUBSCRIPTIONS(43,44) AND THEN BELOW CODE
		EntityTransaction trans = manager.getTransaction();
		trans.begin();
		Customer cust = manager.find(Customer.class, 6);
		Subscription sub = manager.find(Subscription.class, 8);
		cust.getSubscriptions().add(sub);
		manager.merge(cust);
		trans.commit();

	}
}
